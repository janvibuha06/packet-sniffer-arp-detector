#!/usr/bin/env python3
"""
NetGuard — Advanced Packet Sniffer + ARP Spoofing Detector
Author  : [Your Name]
College : [Your College Name]
Year    : Final Year Project

ETHICAL NOTICE:
    Run this tool ONLY on networks you own or have explicit permission to monitor.
    Unauthorized packet capture may be illegal in your jurisdiction.
"""
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon
from gui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("NetGuard")
    app.setOrganizationName("FinalYearProject")

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
