"""
ARP Spoofing Detector
Monitors IP-to-MAC mappings and raises alerts on suspicious changes.
"""
from models.alert_model import AlertInfo


class ARPDetector:
    def __init__(self, alert_callback=None):
        self._ip_mac_cache: dict[str, str] = {}
        self._alert_callback = alert_callback  # function(AlertInfo)

    def set_callback(self, callback):
        self._alert_callback = callback

    def process_arp(self, src_ip: str, src_mac: str) -> AlertInfo | None:
        """
        Check if the IP->MAC mapping has changed.
        Returns AlertInfo if spoofing detected, else None.
        """
        if not src_ip or not src_mac:
            return None

        if src_ip in self._ip_mac_cache:
            known_mac = self._ip_mac_cache[src_ip]
            if known_mac.lower() != src_mac.lower():
                alert = AlertInfo.arp_spoof(src_ip, known_mac, src_mac)
                # Update cache with new MAC
                self._ip_mac_cache[src_ip] = src_mac
                if self._alert_callback:
                    self._alert_callback(alert)
                return alert
        else:
            # First time seeing this IP — add to trusted cache
            self._ip_mac_cache[src_ip] = src_mac

        return None

    def get_arp_table(self) -> list[tuple[str, str]]:
        """Returns current trusted IP->MAC table."""
        return list(self._ip_mac_cache.items())

    def clear(self):
        self._ip_mac_cache.clear()
