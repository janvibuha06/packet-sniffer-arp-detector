"""
Logger — saves packets and alerts to CSV / TXT report.
"""
import csv
import os
from datetime import datetime
from models.packet_model import PacketInfo
from models.alert_model import AlertInfo


class Logger:
    def __init__(self, log_dir="logs", report_dir="reports"):
        self.log_dir = log_dir
        self.report_dir = report_dir
        os.makedirs(log_dir, exist_ok=True)
        os.makedirs(report_dir, exist_ok=True)

        self._packets: list[PacketInfo] = []
        self._alerts: list[AlertInfo] = []

    def log_packet(self, pkt: PacketInfo):
        self._packets.append(pkt)

    def log_alert(self, alert: AlertInfo):
        self._alerts.append(alert)

    def export_packets_csv(self) -> str:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(self.log_dir, f"packets_{ts}.csv")
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Time", "Protocol", "Src IP", "Dst IP", "Src MAC", "Dst MAC", "Length", "Summary"])
            for p in self._packets:
                writer.writerow([p.timestamp, p.protocol, p.src_ip, p.dst_ip,
                                  p.src_mac, p.dst_mac, p.length, p.summary])
        return path

    def export_report_txt(self, counters: dict, arp_table: list) -> str:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(self.report_dir, f"report_{ts}.txt")
        with open(path, "w") as f:
            f.write("=" * 60 + "\n")
            f.write("  NETWORK AUDIT REPORT\n")
            f.write(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 60 + "\n\n")

            f.write("PACKET COUNTERS:\n")
            for k, v in counters.items():
                f.write(f"  {k:10}: {v}\n")

            f.write("\nARP TABLE (IP -> MAC):\n")
            for ip, mac in arp_table:
                f.write(f"  {ip:20} -> {mac}\n")

            f.write(f"\nALERTS ({len(self._alerts)} total):\n")
            for a in self._alerts:
                f.write(f"  [{a.severity}] {a.timestamp} | {a.message}\n")

            f.write("\n" + "=" * 60 + "\n")
            f.write("NOTE: For authorized network use only.\n")
        return path

    def clear(self):
        self._packets.clear()
        self._alerts.clear()
