"""
Packet Sniffer Core — uses Scapy in a background thread.
"""
import threading
from scapy.all import sniff, ARP
from models.packet_model import PacketInfo
from core.arp_detector import ARPDetector


class PacketSniffer:
    def __init__(self, packet_callback=None, alert_callback=None):
        self._packet_callback = packet_callback
        self._running = False
        self._thread = None
        self._iface = None

        # Protocol counters
        self.counters = {"ARP": 0, "TCP": 0, "UDP": 0, "ICMP": 0, "OTHER": 0, "TOTAL": 0}

        # ARP detector
        self.arp_detector = ARPDetector(alert_callback=alert_callback)

    def set_callbacks(self, packet_cb, alert_cb):
        self._packet_callback = packet_cb
        self.arp_detector.set_callback(alert_cb)

    def start(self, iface=None):
        if self._running:
            return
        self._iface = iface
        self._running = True
        self._thread = threading.Thread(target=self._sniff_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _sniff_loop(self):
        sniff(
            iface=self._iface,
            prn=self._handle_packet,
            store=False,
            stop_filter=lambda _: not self._running
        )

    def _handle_packet(self, pkt):
        info = PacketInfo.from_scapy(pkt)

        # Update counters
        self.counters["TOTAL"] += 1
        proto = info.protocol
        if proto in self.counters:
            self.counters[proto] += 1
        else:
            self.counters["OTHER"] += 1

        # ARP spoofing check
        if pkt.haslayer(ARP) and pkt[ARP].op == 2:  # ARP Reply only
            self.arp_detector.process_arp(info.src_ip, info.src_mac)

        if self._packet_callback:
            self._packet_callback(info)

    def reset_counters(self):
        for k in self.counters:
            self.counters[k] = 0
