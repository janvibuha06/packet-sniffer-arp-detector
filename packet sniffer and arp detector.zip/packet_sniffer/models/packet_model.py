from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class PacketInfo:
    timestamp: str = ""
    src_ip: str = ""
    dst_ip: str = ""
    src_mac: str = ""
    dst_mac: str = ""
    protocol: str = ""
    length: int = 0
    summary: str = ""

    @staticmethod
    def from_scapy(pkt):
        from scapy.all import IP, ARP, TCP, UDP, ICMP, Ether
        info = PacketInfo()
        info.timestamp = datetime.now().strftime("%H:%M:%S")
        info.length = len(pkt)

        if pkt.haslayer(Ether):
            info.src_mac = pkt[Ether].src
            info.dst_mac = pkt[Ether].dst

        if pkt.haslayer(ARP):
            info.protocol = "ARP"
            info.src_ip = pkt[ARP].psrc
            info.dst_ip = pkt[ARP].pdst
            info.summary = f"ARP {'Request' if pkt[ARP].op == 1 else 'Reply'}"
        elif pkt.haslayer(IP):
            info.src_ip = pkt[IP].src
            info.dst_ip = pkt[IP].dst
            if pkt.haslayer(TCP):
                info.protocol = "TCP"
                info.summary = f"TCP {pkt[IP].src}:{pkt[TCP].sport} → {pkt[IP].dst}:{pkt[TCP].dport}"
            elif pkt.haslayer(UDP):
                info.protocol = "UDP"
                info.summary = f"UDP {pkt[IP].src}:{pkt[UDP].sport} → {pkt[IP].dst}:{pkt[UDP].dport}"
            elif pkt.haslayer(ICMP):
                info.protocol = "ICMP"
                info.summary = f"ICMP {pkt[IP].src} → {pkt[IP].dst}"
            else:
                info.protocol = "IP"
                info.summary = f"IP {pkt[IP].src} → {pkt[IP].dst}"
        else:
            info.protocol = "OTHER"
            info.summary = pkt.summary()

        return info
