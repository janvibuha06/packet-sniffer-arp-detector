from dataclasses import dataclass
from datetime import datetime

@dataclass
class AlertInfo:
    timestamp: str = ""
    severity: str = "LOW"   # LOW / MEDIUM / HIGH
    alert_type: str = ""
    ip: str = ""
    old_mac: str = ""
    new_mac: str = ""
    message: str = ""

    @staticmethod
    def arp_spoof(ip, old_mac, new_mac):
        a = AlertInfo()
        a.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        a.severity = "HIGH"
        a.alert_type = "ARP Spoofing Detected"
        a.ip = ip
        a.old_mac = old_mac
        a.new_mac = new_mac
        a.message = f"IP {ip} changed MAC from {old_mac} to {new_mac}"
        return a
