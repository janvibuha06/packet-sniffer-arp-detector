# NetGuard — Advanced Packet Sniffer + ARP Spoofing Detector

## Project Title
Advanced Packet Sniffer + ARP Spoofing Detector (using Scapy)

## Problem Statement
ARP spoofing (also called ARP poisoning) is a common technique attackers use on local networks to intercept, redirect, or modify traffic. This tool detects such attacks in real-time by monitoring IP-to-MAC mappings and identifying anomalies.

## Features
- Live packet capture with protocol-wise color coding
- Real-time ARP spoofing detection
- Trusted ARP table monitoring (IP → MAC mapping)
- Alert panel with severity levels
- Protocol statistics dashboard (ARP, TCP, UDP, ICMP)
- CSV packet export + audit report generation
- Dark-themed professional GUI (PyQt6)

## Project Structure
```
packet_sniffer/
├── main.py                  # Entry point
├── requirements.txt
├── gui/
│   ├── main_window.py       # Main application window
│   ├── packet_table.py      # Live packet display table
│   ├── alert_panel.py       # ARP alert panel
│   └── arp_table.py         # Trusted ARP table display
├── core/
│   ├── sniffer.py           # Scapy packet capture engine
│   ├── arp_detector.py      # ARP spoofing detection logic
│   └── logger.py            # CSV/report export
├── models/
│   ├── packet_model.py      # PacketInfo dataclass
│   └── alert_model.py       # AlertInfo dataclass
├── logs/                    # Auto-generated CSV logs
└── reports/                 # Auto-generated audit reports
```

## Installation
```bash
pip install PyQt6 scapy
```

## Running (requires root/admin for packet capture)
```bash
# Linux/Mac
sudo python3 main.py

# Windows (run as Administrator)
python main.py
```

## ARP Spoofing Detection Logic
1. Observe ARP Reply packets on the network
2. Maintain a trusted IP → MAC mapping cache
3. If same IP reports a different MAC → raise HIGH severity alert
4. GUI shows severity, timestamp, old MAC, and new MAC

## Ethical Notice
> **Run this tool ONLY on networks you own or have explicit written permission to monitor.**
> Packet capture and network monitoring may be illegal in some environments.
> Always obtain permission before scanning or sniffing networks.

## Practical Use Cases
- Real-time ARP spoofing detection on local networks
- Network forensics and packet capture for later analysis
- Educational tool to learn packet structures, ARP protocol, and defensive techniques
- Useful in small networks, labs, and as a monitoring component in a larger security setup
- SOC (Security Operations Center) training environment simulation

## Limitations
- Works on local LAN only (not routed/WAN networks)
- Requires root/administrator privileges for raw socket access
- False positives possible when devices legitimately change NICs
- Does not block attacks — detection only (defensive tool)

## Tech Stack
- Python 3.10+
- Scapy (packet capture & analysis)
- PyQt6 (modern desktop GUI)
