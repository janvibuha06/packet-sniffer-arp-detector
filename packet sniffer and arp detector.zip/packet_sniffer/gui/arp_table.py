"""
ARP Table Widget — shows current trusted IP-to-MAC mapping.
"""
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QTableWidget,
                              QTableWidgetItem, QLabel, QHBoxLayout, QPushButton)
from PyQt6.QtGui import QColor


class ARPTableWidget(QWidget):
    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)

        header = QHBoxLayout()
        title = QLabel("🗺️ ARP Table (Trusted IP → MAC)")
        title.setStyleSheet("font-weight: bold; font-size: 13px;")
        clear_btn = QPushButton("Clear Table")
        clear_btn.clicked.connect(self.clear)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(clear_btn)
        layout.addLayout(header)

        self._table = QTableWidget(0, 2)
        self._table.setHorizontalHeaderLabels(["IP Address", "MAC Address"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        layout.addWidget(self._table)

    def update_table(self, entries: list[tuple[str, str]]):
        """Refresh the entire ARP table display."""
        self._table.setRowCount(0)
        for ip, mac in entries:
            row = self._table.rowCount()
            self._table.insertRow(row)
            self._table.setItem(row, 0, QTableWidgetItem(ip))
            self._table.setItem(row, 1, QTableWidgetItem(mac))

    def clear(self):
        self._table.setRowCount(0)
