"""
Packet Table — live scrolling table showing captured packets.
"""
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QTableWidget,
                              QTableWidgetItem, QLabel, QHBoxLayout,
                              QComboBox, QLineEdit)
from PyQt6.QtGui import QColor
from PyQt6.QtCore import Qt
from models.packet_model import PacketInfo

PROTO_COLORS = {
    "ARP":   "#4fc3f7",
    "TCP":   "#81c784",
    "UDP":   "#ffb74d",
    "ICMP":  "#ce93d8",
    "OTHER": "#eeeeee",
    "IP":    "#80cbc4",
}

MAX_ROWS = 1000  # Prevent memory overflow


class PacketTable(QWidget):
    def __init__(self):
        super().__init__()
        self._all_packets: list[PacketInfo] = []
        self._filter_proto = "ALL"
        self._filter_text = ""
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)

        # Filter bar
        filter_bar = QHBoxLayout()
        filter_bar.addWidget(QLabel("Protocol:"))
        self._proto_combo = QComboBox()
        self._proto_combo.addItems(["ALL", "ARP", "TCP", "UDP", "ICMP", "OTHER"])
        self._proto_combo.currentTextChanged.connect(self._apply_filter)
        filter_bar.addWidget(self._proto_combo)

        filter_bar.addWidget(QLabel("Search:"))
        self._search_box = QLineEdit()
        self._search_box.setPlaceholderText("IP / MAC / Summary...")
        self._search_box.textChanged.connect(self._apply_filter)
        filter_bar.addWidget(self._search_box)
        layout.addLayout(filter_bar)

        # Table
        self._table = QTableWidget(0, 7)
        self._table.setHorizontalHeaderLabels(
            ["Time", "Protocol", "Src IP", "Dst IP", "Src MAC", "Length", "Summary"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self._table)

    def add_packet(self, pkt: PacketInfo):
        self._all_packets.append(pkt)
        if len(self._all_packets) > MAX_ROWS:
            self._all_packets.pop(0)

        # Only display if passes filter
        if self._passes_filter(pkt):
            self._insert_row(pkt)
            if self._table.rowCount() > MAX_ROWS:
                self._table.removeRow(0)
            self._table.scrollToBottom()

    def _passes_filter(self, pkt: PacketInfo) -> bool:
        if self._filter_proto != "ALL" and pkt.protocol != self._filter_proto:
            return False
        if self._filter_text:
            txt = self._filter_text.lower()
            haystack = f"{pkt.src_ip} {pkt.dst_ip} {pkt.src_mac} {pkt.summary}".lower()
            if txt not in haystack:
                return False
        return True

    def _insert_row(self, pkt: PacketInfo):
        row = self._table.rowCount()
        self._table.insertRow(row)
        color = QColor(PROTO_COLORS.get(pkt.protocol, "#ffffff"))
        values = [pkt.timestamp, pkt.protocol, pkt.src_ip,
                  pkt.dst_ip, pkt.src_mac, str(pkt.length), pkt.summary]
        for col, val in enumerate(values):
            item = QTableWidgetItem(val)
            item.setBackground(color)
            item.setForeground(QColor("#111111"))
            self._table.setItem(row, col, item)

    def _apply_filter(self):
        self._filter_proto = self._proto_combo.currentText()
        self._filter_text = self._search_box.text().strip()
        self._table.setRowCount(0)
        for pkt in self._all_packets:
            if self._passes_filter(pkt):
                self._insert_row(pkt)

    def clear(self):
        self._all_packets.clear()
        self._table.setRowCount(0)
