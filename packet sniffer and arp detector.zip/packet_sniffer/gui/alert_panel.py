"""
Alert Panel — shows ARP spoofing alerts with color coding.
"""
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QTableWidget,
                              QTableWidgetItem, QLabel, QPushButton, QHBoxLayout)
from PyQt6.QtGui import QColor
from PyQt6.QtCore import Qt
from models.alert_model import AlertInfo


SEVERITY_COLORS = {
    "HIGH":   "#ff4444",
    "MEDIUM": "#ff8800",
    "LOW":    "#ffcc00",
}


class AlertPanel(QWidget):
    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QHBoxLayout()
        title = QLabel("🚨 Alert Panel")
        title.setStyleSheet("font-weight: bold; font-size: 14px; color: #ff4444;")
        self._count_label = QLabel("Alerts: 0")
        self._count_label.setStyleSheet("color: #aaa;")
        clear_btn = QPushButton("Clear Alerts")
        clear_btn.clicked.connect(self.clear_alerts)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self._count_label)
        header.addWidget(clear_btn)
        layout.addLayout(header)

        # Table
        self._table = QTableWidget(0, 5)
        self._table.setHorizontalHeaderLabels(["Time", "Severity", "IP", "Old MAC", "New MAC"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self._table)

    def add_alert(self, alert: AlertInfo):
        row = self._table.rowCount()
        self._table.insertRow(row)

        color = QColor(SEVERITY_COLORS.get(alert.severity, "#ffffff"))
        items = [alert.timestamp, alert.severity, alert.ip, alert.old_mac, alert.new_mac]

        for col, text in enumerate(items):
            item = QTableWidgetItem(text)
            item.setBackground(color)
            item.setForeground(QColor("#000000"))
            self._table.setItem(row, col, item)

        self._table.scrollToBottom()
        self._count_label.setText(f"Alerts: {row + 1}")

    def clear_alerts(self):
        self._table.setRowCount(0)
        self._count_label.setText("Alerts: 0")
