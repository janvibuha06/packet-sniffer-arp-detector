"""
Main Window — central hub of the application.
Tabs: Packet Capture | ARP Table | Alerts | Statistics
"""
import sys
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                              QTabWidget, QLabel, QPushButton, QComboBox,
                              QStatusBar, QMessageBox, QFileDialog, QGroupBox,
                              QGridLayout)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt6.QtGui import QFont

from gui.packet_table import PacketTable
from gui.alert_panel import AlertPanel
from gui.arp_table import ARPTableWidget
from core.sniffer import PacketSniffer
from core.logger import Logger
from models.packet_model import PacketInfo
from models.alert_model import AlertInfo

import random


# ─── Signal bridge (thread-safe GUI updates) ───────────────────────────────
class SignalBridge(QObject):
    packet_received = pyqtSignal(object)
    alert_received  = pyqtSignal(object)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NetGuard — Advanced Packet Sniffer + ARP Spoofing Detector")
        self.resize(1200, 750)

        self._bridge = SignalBridge()
        self._bridge.packet_received.connect(self._on_packet)
        self._bridge.alert_received.connect(self._on_alert)

        self._sniffer = PacketSniffer(
            packet_callback=self._bridge.packet_received.emit,
            alert_callback=self._bridge.alert_received.emit
        )
        self._logger = Logger()
        self._capturing = False

        self._setup_ui()

        # ARP table refresh timer
        self._arp_timer = QTimer()
        self._arp_timer.timeout.connect(self._refresh_arp_table)
        self._arp_timer.start(2000)

        # Stats refresh timer
        self._stats_timer = QTimer()
        self._stats_timer.timeout.connect(self._refresh_stats)
        self._stats_timer.start(1000)

    # ── UI Setup ────────────────────────────────────────────────────────────
    def _setup_ui(self):
        self._apply_dark_theme()

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 8)

        # ── Top toolbar ──
        toolbar = QHBoxLayout()

        toolbar.addWidget(QLabel("Interface:"))
        self._iface_combo = QComboBox()
        self._iface_combo.addItem("default (auto)")
        self._iface_combo.setMinimumWidth(160)
        toolbar.addWidget(self._iface_combo)

        self._start_btn = QPushButton("▶  Start Capture")
        self._start_btn.setStyleSheet("background:#27ae60; color:white; font-weight:bold; padding:6px 16px;")
        self._start_btn.clicked.connect(self._toggle_capture)
        toolbar.addWidget(self._start_btn)

        self._clear_btn = QPushButton("🗑  Clear All")
        self._clear_btn.clicked.connect(self._clear_all)
        toolbar.addWidget(self._clear_btn)

        self._export_csv_btn = QPushButton("📄 Export CSV")
        self._export_csv_btn.clicked.connect(self._export_csv)
        toolbar.addWidget(self._export_csv_btn)

        self._export_report_btn = QPushButton("📋 Export Report")
        self._export_report_btn.clicked.connect(self._export_report)
        toolbar.addWidget(self._export_report_btn)

        # ── SIMULATE BUTTON ──
        self._simulate_btn = QPushButton("⚠️  Simulate ARP Attack")
        self._simulate_btn.setStyleSheet(
            "background:#e67e22; color:white; font-weight:bold; padding:6px 16px; border-radius:4px;")
        self._simulate_btn.clicked.connect(self._simulate_arp_attack)
        toolbar.addWidget(self._simulate_btn)

        toolbar.addStretch()

        # Alert badge
        self._alert_badge = QLabel("🔴 Alerts: 0")
        self._alert_badge.setStyleSheet("color:#ff4444; font-weight:bold; font-size:14px;")
        toolbar.addWidget(self._alert_badge)

        root.addLayout(toolbar)

        # ── Stats bar ──
        stats_group = QGroupBox("Live Statistics")
        stats_layout = QGridLayout(stats_group)
        self._stat_labels: dict[str, QLabel] = {}
        for i, proto in enumerate(["TOTAL", "ARP", "TCP", "UDP", "ICMP", "OTHER"]):
            lbl = QLabel(f"{proto}: 0")
            lbl.setStyleSheet("font-size:13px; font-weight:bold; color:#4fc3f7;")
            stats_layout.addWidget(lbl, 0, i)
            self._stat_labels[proto] = lbl
        root.addWidget(stats_group)

        # ── Tabs ──
        self._tabs = QTabWidget()
        self._packet_table = PacketTable()
        self._alert_panel = AlertPanel()
        self._arp_widget = ARPTableWidget()

        self._tabs.addTab(self._packet_table, "📦 Packet Capture")
        self._tabs.addTab(self._arp_widget,   "🗺️  ARP Table")
        self._tabs.addTab(self._alert_panel,  "🚨 Alerts")
        root.addWidget(self._tabs)

        # ── Status bar ──
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage("Ready — Select interface and press Start Capture.")

    # ── SIMULATE ARP ATTACK ─────────────────────────────────────────────────
    def _simulate_arp_attack(self):
        """
        Simulates ARP spoofing scenario for demo/testing purposes.
        Injects fake packets and triggers spoof alerts — no real network traffic.
        """
        import random
        from datetime import datetime

        # Step 1: Add some legit packets to packet table
        legit_packets = [
            ("192.168.1.1",  "192.168.1.10", "aa:bb:cc:11:22:33", "TCP"),
            ("192.168.1.10", "192.168.1.1",  "dd:ee:ff:44:55:66", "UDP"),
            ("192.168.1.1",  "192.168.1.20", "aa:bb:cc:11:22:33", "ARP"),
            ("192.168.1.5",  "192.168.1.1",  "11:22:33:44:55:66", "ICMP"),
        ]

        for src_ip, dst_ip, src_mac, proto in legit_packets:
            pkt = PacketInfo()
            pkt.timestamp = datetime.now().strftime("%H:%M:%S")
            pkt.src_ip    = src_ip
            pkt.dst_ip    = dst_ip
            pkt.src_mac   = src_mac
            pkt.protocol  = proto
            pkt.length    = random.randint(64, 1500)
            pkt.summary   = f"{proto} {src_ip} → {dst_ip}"
            self._packet_table.add_packet(pkt)

        # Step 2: Seed ARP detector with legit mappings
        self._sniffer.arp_detector._ip_mac_cache = {
            "192.168.1.1":  "aa:bb:cc:11:22:33",   # Router (legitimate)
            "192.168.1.10": "dd:ee:ff:44:55:66",   # PC1 (legitimate)
            "192.168.1.20": "11:22:33:44:55:66",   # PC2 (legitimate)
        }
        self._refresh_arp_table()

        # Step 3: Simulate attacker sending fake ARP reply
        # Attacker's MAC: ff:00:ff:00:ff:00 pretending to be the router
        attacker_mac = "ff:00:ff:00:ff:00"
        victim_ip    = "192.168.1.1"   # Attacker is impersonating the router

        # Inject spoofed ARP packet into packet table
        spoof_pkt = PacketInfo()
        spoof_pkt.timestamp = datetime.now().strftime("%H:%M:%S")
        spoof_pkt.src_ip    = victim_ip
        spoof_pkt.dst_ip    = "255.255.255.255"
        spoof_pkt.src_mac   = attacker_mac
        spoof_pkt.protocol  = "ARP"
        spoof_pkt.length    = 42
        spoof_pkt.summary   = f"[SPOOFED] ARP Reply: {victim_ip} is at {attacker_mac}"
        self._packet_table.add_packet(spoof_pkt)

        # Step 4: Trigger alert via detector
        alert = AlertInfo.arp_spoof(
            ip      = victim_ip,
            old_mac = "aa:bb:cc:11:22:33",
            new_mac = attacker_mac
        )
        alert.message = f"[SIMULATED] Router IP {victim_ip} changed MAC → possible MITM attack!"
        self._on_alert(alert)

        self._status.showMessage("⚠️ Simulation complete! Check Alerts tab.")

    # ── Capture control ─────────────────────────────────────────────────────
    def _toggle_capture(self):
        if not self._capturing:
            iface = self._iface_combo.currentText()
            iface = None if iface == "default (auto)" else iface
            self._sniffer.start(iface=iface)
            self._capturing = True
            self._start_btn.setText("⏹  Stop Capture")
            self._start_btn.setStyleSheet("background:#c0392b; color:white; font-weight:bold; padding:6px 16px;")
            self._status.showMessage(f"Capturing on {'default' if iface is None else iface}...")
        else:
            self._sniffer.stop()
            self._capturing = False
            self._start_btn.setText("▶  Start Capture")
            self._start_btn.setStyleSheet("background:#27ae60; color:white; font-weight:bold; padding:6px 16px;")
            self._status.showMessage("Capture stopped.")

    # ── Callbacks ────────────────────────────────────────────────────────────
    def _on_packet(self, pkt: PacketInfo):
        self._packet_table.add_packet(pkt)
        self._logger.log_packet(pkt)

    def _on_alert(self, alert: AlertInfo):
        self._alert_panel.add_alert(alert)
        self._logger.log_alert(alert)
        count = self._alert_panel._table.rowCount()
        self._alert_badge.setText(f"🔴 Alerts: {count}")
        self._tabs.setCurrentIndex(2)
        self._status.showMessage(f"⚠️  ALERT: {alert.message}")

    # ── Timer callbacks ───────────────────────────────────────────────────────
    def _refresh_arp_table(self):
        entries = self._sniffer.arp_detector.get_arp_table()
        self._arp_widget.update_table(entries)

    def _refresh_stats(self):
        for proto, lbl in self._stat_labels.items():
            lbl.setText(f"{proto}: {self._sniffer.counters.get(proto, 0)}")

    # ── Actions ───────────────────────────────────────────────────────────────
    def _clear_all(self):
        self._packet_table.clear()
        self._alert_panel.clear_alerts()
        self._arp_widget.clear()
        self._sniffer.reset_counters()
        self._sniffer.arp_detector.clear()
        self._logger.clear()
        self._alert_badge.setText("🔴 Alerts: 0")
        self._status.showMessage("Cleared.")

    def _export_csv(self):
        path = self._logger.export_packets_csv()
        QMessageBox.information(self, "Exported", f"Packets saved to:\n{path}")

    def _export_report(self):
        path = self._logger.export_report_txt(
            self._sniffer.counters,
            self._sniffer.arp_detector.get_arp_table()
        )
        QMessageBox.information(self, "Report Exported", f"Report saved to:\n{path}")

    # ── Dark theme ────────────────────────────────────────────────────────────
    def _apply_dark_theme(self):
        self.setStyleSheet("""
            QMainWindow, QWidget { background-color: #1e1e2e; color: #cdd6f4; }
            QTabWidget::pane { border: 1px solid #45475a; }
            QTabBar::tab { background: #313244; color: #cdd6f4; padding: 8px 16px; }
            QTabBar::tab:selected { background: #89b4fa; color: #1e1e2e; font-weight: bold; }
            QTableWidget { background: #181825; gridline-color: #313244; color: #cdd6f4; }
            QHeaderView::section { background: #313244; color: #89b4fa; padding: 4px; font-weight: bold; }
            QPushButton { background: #313244; color: #cdd6f4; border: 1px solid #45475a; padding: 5px 12px; border-radius: 4px; }
            QPushButton:hover { background: #45475a; }
            QComboBox { background: #313244; color: #cdd6f4; border: 1px solid #45475a; padding: 4px; }
            QLineEdit { background: #313244; color: #cdd6f4; border: 1px solid #45475a; padding: 4px; border-radius: 3px; }
            QGroupBox { border: 1px solid #45475a; border-radius: 4px; margin-top: 8px; padding: 8px; }
            QGroupBox::title { color: #89b4fa; subcontrol-origin: margin; left: 8px; }
            QStatusBar { background: #181825; color: #a6e3a1; }
        """)
